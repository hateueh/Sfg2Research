import os
import zipfile
import struct

obb = "/storage/emulated/0/MT2/main.172.com.ForgeGames.SpecialForcesGroup2.obb"
member = "SpecialForces/Content/Paks/SpecialForces-Android_Multi.pak"

with zipfile.ZipFile(obb) as z:
    info = z.getinfo(member)
    print("Compressed size:", info.compress_size)
    print("Uncompressed size:", info.file_size)

    with z.open(member) as f:
        head = f.read(64)
        print("First 64 bytes:", head.hex(" "))

        f.seek(0, os.SEEK_END)
        print("Seek-to-end supported:", f.tell() == info.file_size)
